# ws1920-datascience
Ressourcen für den Kurs Einführung in Data Science und maschinelles Lernen mit R
